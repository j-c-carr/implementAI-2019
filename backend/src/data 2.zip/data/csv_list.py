import pandas as pd
import numpy as np
import json

def listElms():
   good_ones = ["VSLR", "RUN", "CSIQ","PEGI","FSLR","SPWR","JKS","ENPH","SEDG", "INE", "TSLA","AQN","DQ","AZRE","ASTI","FP", "YGEHY","SUNW","RGSE","EVSI"]
   list_dict = {}
   for ticker in good_ones:
       # for some companies I was not able to get the prices
       try:
           df = pd.read_csv("./prices/"+ticker+".csv")
           df.drop(df.tail(180).index, inplace=True)
           list_dict[ticker] = {'timestamps':df['Date'].tolist(), 'prices':{"High":df['High'].tolist(), "Open":df['Open'].tolist(), "Low":df['Low'].tolist(), "Close": df['Close'].tolist()}}
       except FileNotFoundError:
           continue
   return list_dict


with open('prices.json', 'w') as f:
    json.dump(listElms(), f)
